#include <stdio.h>

int main()
{
    char note; 
    printf ("Enter a note on the C Major scale: ");
    scanf("%c", &note);
   
switch (note) 
    {
        case 'C':
            printf("The third of C is E. \n");
            break;
        case 'D':
            printf("The third of D is F.\n");
            break;
        case 'E':
            printf("The third of E is G.\n");
            break;
        case 'F':
            printf("The third of F is A.\n");
            break;
        case 'G':
            printf("The third of G is B.\n");
            break;
        case 'A':
            printf("The third of A is C.\n");
            break;
        case 'B':
            printf("The third of B is D.\n");
            break;
        default:
            printf("Error please enter a capital letter on the The C Major scale, {C, D, E, F, G, A, B}.\n");
            break;
    }

    return 0;
}