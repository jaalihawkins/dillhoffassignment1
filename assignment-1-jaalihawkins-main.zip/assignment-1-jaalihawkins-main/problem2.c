#include <stdio.h>

int main() 
{
    float a = 0;
    float b = 0;
    
    printf("Enter the first number: ");
    scanf("%f", &a);
    printf("Enter the second number: ");
    scanf("%f", &b);
    
    float result = a * b;
    
    printf("%f\n", result);
    
    return 0;
}