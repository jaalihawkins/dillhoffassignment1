
#include <stdio.h>

int main()
{
    int a = 66, b = 65, c = 67, d = 72;
    printf("%c%c%c%c\n", a, b, c, d);
    
    return 0;
}