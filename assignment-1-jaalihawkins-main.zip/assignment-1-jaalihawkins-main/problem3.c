#include <stdio.h>

int main()
{
    double mass = 72.3;
    double velocity = 101.6;
    double kinetic_energy = (0.5) * mass * velocity * velocity;
    printf("%.3lf\n", kinetic_energy);

    return 0;
}