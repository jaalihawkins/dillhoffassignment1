#include <stdio.h>

int main() 
{
    int surface_area;
    int side_length;

    printf("Enter the side length: ");
    scanf("%d", &side_length);

     surface_area = 6 * (side_length * side_length);

    printf("Surface Area = %d\n", surface_area);

    return 0;
}