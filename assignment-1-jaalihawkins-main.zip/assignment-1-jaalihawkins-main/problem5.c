#include <stdio.h>

int main()
{
    char char1, char2, char3; 

    printf ("Enter Three characters: ");

    scanf("%c%c%c", &char1,&char2,&char3);
    getchar(); 


    printf("%c%c%c\n", char3, char2, char1);


    return 0;
}