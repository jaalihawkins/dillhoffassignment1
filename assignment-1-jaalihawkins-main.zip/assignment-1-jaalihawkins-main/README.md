# CSE1310 Assignment 1

Make sure that all code compiles without warnings and errors, even when you use the compilation flag `-Wall`.

## (12%) Problem 1

Compile and run the following code then observe the output.

```
#include <stdio.h>

int main() {
    int a = 65, b = 64, c = 66, d = 71;
    printf("%c%c%c%c\n", a, b, c, d);
    
    return 0;
}
```

Modify the code by adding 1 to each variable. You may do this however you wish. Make sure the code compiles with no warnings or errors and save it as `problem1.c`.

## (16%) Problem 2

The following code should read **two floating-point values** from the user, multiply them, and print the result to the third decimal place.
It currently does not work as requested. Fix the code so that it works as stated above.

```
#include <stdio.h>

int main() {
    int a = 0;
    float b = 0;
    
    printf("Enter the first number: ");
    scanf("%d", &a);
    printf("Enter the second number: ");
    scanf("%f", b);
    
    float result = a * b;
    
    printf("%d\n", result);
    
    return 0;
}
```

Save your code as `problem2.c`.

## (16%) Problem 3

The following program calculates the kinetic energy of a physical body in motion given the mass and velocity, $K = \frac{1}{2}mv^2$.
It should print the result as a **double precision floating-point number** (the format specifier for double is `%lf`), truncated to the first 3 decimal values.

```
#include <stdio.h>

int main() {
    int mass = 72.3;
    int velocity = 101.6;
    int kinetic_energy = (1 / 2) * mass * velocity * velocity;
    printf("%d\n", kinetic_energy);

    return 0;
}
```

- Fix the program so that is produces a correct result.
- Save the code as `problem3.c`.

## (18%) Problem 4

The surface area of a cube is calculated by combining the area of each of its
6 faces, where each face is a square whose area is the square of its side length. Thus, the
surface area of a cube is $A = 6s^2$. The following program attempts to calculate the area
of a cube, but does not compile correctly. It should request the side length from the user and print the surface area of the cube.

**All values should be integers.**

```
#include <stdio.h>

int main() {
    int surface_area = side_length * side_length;
    int side_length = 5;

    printf("Surface Area = %d\n", surface_area);

    return 0;
}
```

Save your code as `problem4.c`.

## (18%) Problem 5

Create a program that reads 3 characters from the user using three separate calls to `scanf`. Since `scanf` using `%c` will leave the newline character in the input buffer, you should use one of the following solutions:

1. Use a space before the `%c` in the format string, e.g. `" %c"`.
2. Use a second `scanf` call to read the newline character.
3. Use a `getchar` call to read the newline character.
4. Use a `scanf` call with a format string of `"%c\n"`.

After reading in the characters, print them in reverse order followed by a newline character.

**Example Run**

```
Enter 3 characters: A B C
CBA
```

Save your code as `problem5.c`.

## (20%) Problem 6

Western music commonly uses the 12-tone equal temperament system, which divides the octave into 12 equal parts. The C Major scale is the set of 7 notes {C, D, E, F, G, A, B}. A third is an interval of 2 tones, so the third of D is F.

Write a program that prompts the user to enter a note (C, D, E, F, G, A, or B) and then prints the third of that note. Your can assume that the user will enter a valid note as a capital letter. Print the result as shown in the example run below. You should not use any `if` statements (Hint: Use the `%` operator).

**Example Run**

```
Enter a note on the C Major scale: G
The third of G is B
```

Save your code as `problem6.c`.